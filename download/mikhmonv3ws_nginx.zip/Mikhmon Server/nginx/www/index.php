<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

  $url = $_SERVER['REQUEST_URI'];
  $pname = explode('/', $url); // mendapatkan path name
  $tpname= $pname[sizeof($pname)-3];
?>
<!DOCTYPE html>
<html>
	<head>
		<title>MIKHMON SERVER</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="pragma" content="no-cache" />
		<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;"/>
		<style>
body{
	font-family: 'Helvetica', arial, sans-serif;
  background-color: #3D4241;
  color: #FFFFFF;
  font-size: 14px;
}
.btnsubmitb {
  background-color: #F3F3F3;
  color: #000;
  border: none;
  padding: 5px 5px;
  font-weight: bold;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  cursor: pointer;
  margin: 2px 2px;
}
.btnsubmitb:hover {
  background-color: #008CCA;
  color: #FFFFFF;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
h3 {
  text-shadow: 2px 2px 6px #424242;
}
		</style>
	</head>
	<body align="center">
	  <div>
	  <h3>MIKHMON SERVER</h3>
	  <?php
	  $dir_open = opendir('.'); // mendapatkan direktori
	  while(false !== ($filename = readdir($dir_open))){ // mendapatkan folder / file
	    if($filename != "." && $filename != ".."){
	      // mengecek path
	      if(substr($url, -1) == "/"){
	        $urlp = substr($url, 0,-1);
	      }else{
	        $urlp = $url;
	      }
	        $linkname = $filename;
	        $link = "<a class='btnsubmitb' title='".strtoupper($filename)."' href='$urlp/$filename'>".strtoupper($linkname)." </a> ";

	      // menyembunyikan file file tertentu
	      if($filename == "error" ||
	      substr($filename, -5) == ".html" ||
	      substr($filename, -4) == ".php"
	      ){}else{
	            //menampilkan folder / file
	            echo "$link ";
	          }
	      }
	   }
	   closedir($dir_open);
	   ?>
	   </div>
	</body>
</html>
	 