<?php 
session_start();
// hide all error
error_reporting(0);
// protect .php
$get_self = explode("/",$_SERVER['PHP_SELF']);
$self[] = $get_self[count($get_self)-1];

if($self[0] !== "index.php"  && $self[0] !==""){
    include_once("../core/func.php");

    e403();

}else{


    $is_mobile = $_GET['mobile'];


if(!isset($is_mobile)){
  

    $hotspot_ma = "sidenav_active";
    
    include_once("view/header_html.php");
    include_once("view/menu.php");
    
    



?>
<div class="main">
    <div class="row">
        <div class="col-12">
            <div class="card ">
            <div class="card-header">
                <h3>Hotspot &nbsp; <span id="loadingX"></span></h3>
            </div>
            <div class="card-body">
            <div class="row">
                <div class="col-12 mr-b-10">
                    <div class="btn-group">
                        <button class="bg-grey" onclick="loadUserProfiles()" id="btn-user-profiles"><i class="fa fa-pie-chart" ></i> User Profile</button> 
                        <button class="bg-grey" onclick="loadUsersPP()" id="btn-hotspot-users"><i class="fa fa-users" ></i> Users</button>
                        <button class="bg-grey" onclick="loadHotspotActive()" id="btn-hotspot-active"><i class="fa fa-wifi" ></i> Active</button>
                        <button class="bg-grey" onclick="loadHotspotHosts()" id="btn-hotspot-hosts"><i class="fa fa-laptop" ></i> Hosts</button>
                    </div>
                    
                </div>
                
                <div class="col-12 hide" id="user-profiles">
                    <div class="">
                    <div class="btn-group">
                    <button class="bg-grey table-total" id="total-profiles" >&nbsp;</button>
                        <button class="bg-grey" onclick="loadUserProfiles()" id="btn-add-user-profiles"><i class="fa fa-plus" ></i>  Add</button> 
                    
                        <button class="bg-grey" onclick="loadUProfiles()"><i class="fa fa-refresh" ></i></button>

                    </div>
                    <hr>
                    </div>
                    <div class="card-fixed">
                    
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <td>Name</td>
                                <td>Shared Users</td>
                                <td>Rate Linit</td>
                                <td>Epired Mode</td>
                                <td>Validity</td>
                                <td>Price</td>
                                <td>Selling Price</td>
                                <td>User Lock</td>
                            </tr>
                        </thead>
                        <tbody id="profiles">

                        </tbody>
                    </table>
                    </div>
                </div>
                <div class="col-12 hide" id="hotspot-users">
                    <div class="">
                    <div class="btn-group">
                        <button class="bg-grey table-total" id="total-users" >&nbsp;</button>
                        <button class="bg-grey" onclick="" id="btn-add-hotspot-users"><i class="fa fa-plus" ></i> Add</button> 
                        <button class="bg-grey" onclick="" id="btn-gen-hotspot-users"><i class="fa fa-ticket" ></i> Generate</button>
                        <button class="bg-grey" onclick="loadUsersPPF()" title="Force reload"><i class="fa fa-refresh" ></i></button>
                        <input type="text" autocomplete = "off" id="filter-user" onkeyup="filterTable('users','filter-user')" placeholder="Filter" />
                        <button class="bg-grey" onclick="filterBy('users','filter-user','')" title="Clear filter"><i class="fa fa-filter" ></i></button>
                        
                        <select class="bg-grey pointer" id="select-profile" value="" onchange="filterBy('users','filter-user',this.value)">
                            <option value="">Profile</option>
                        </select>
                        <select class="bg-grey pointer" id="select-comment" value="" onchange="filterBy('users','filter-user',this.value)">
                            <option value="">Comment</option>
                        </select>
                       
                    </div>
                    <hr>
                    </div>
                    <div class="card-fixed">
                    
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <td></td>
                                <td>Name</td>
                                <td>Profile</td>
                                <td class="text-right">Uptime</td>
                                <td class="text-right">Bites In</td>
                                <td class="text-right">Bytes Out</td>
                                <td>Comment</td>
                            </tr>
                        </thead>
                        <tbody id="users">

                        </tbody>
                    </table>
                    </div>
                </div>
                <div class="col-12 hide" id="hotspot-active">
                    <div class="">
                        <div class="btn-group">
                            <button class="bg-grey table-total" id="total-active" >&nbsp;</button>
                            <button class="bg-grey" onclick="loadHotspotActive()" title="Force reload"><i class="fa fa-refresh" ></i></button>
                            <input type="text" autocomplete = "off" id="filter-hotspot-active" onkeyup="filterTable('active','filter-hotspot-active')" placeholder="Filter" />
                            <button class="bg-grey" onclick="filterBy('active','filter-hotspot-active','')" title="Clear filter"><i class="fa fa-filter" ></i></button>
                            <select class="bg-grey pointer" id="select-server" value="" onchange="filterBy('active','filter-hotspot-active',this.value)">
                            <option value="">Server</option>
                        </select>
                        </div>
                    <hr>
                    </div>
                    <div class="card-fixed">
                    
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <td>Server</td>
                                <td>User</td>
                                <td>Address</td>
                                <td>MAC Address</td>
                                <td class="text-right">Uptime</td>
                                <td class="text-right">Bites In</td>
                                <td class="text-right">Bytes Out</td>
                                <td>Time Left</td>
                                <td>Login By</td>
                                <td>Comment</td>
                            </tr>
                        </thead>
                        <tbody id="active" class="text-nowrap">

                        </tbody>
                    </table>
                    </div>
                </div>
                <div class="col-12 hide" id="hotspot-hosts">
                    <div class="">
                        <div class="btn-group">
                            <button class="bg-grey table-total" id="total-hosts" >&nbsp;</button>
                            <button class="bg-grey" onclick="loadHotspotHosts()" title="Force reload"><i class="fa fa-refresh" ></i></button>
                            <input type="text" autocomplete = "off" id="filter-hosts" onkeyup="filterTable('hosts','filter-hosts')" placeholder="Filter" />
                            <button class="bg-grey" onclick="filterBy('active','filter-hosts','')" title="Clear filter"><i class="fa fa-filter" ></i></button>

                        </select>
                        </div>
                    <hr>
                    </div>
                    <div class="card-fixed">
                    
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <td></td>
                                <td>Mac Address</td>
                                <td>Address</td>
                                <td>To Address</td>
                                <td>Server</td>
                                <td>Comment</td>
                            </tr>
                        </thead>
                        <tbody id="hosts" class="text-nowrap">

                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            </div>
            <div class="card-footer"><span id="loading"></span> </div>
            </div>
        </div>
    </div>
</div>
<?php 

}else if(isset($is_mobile)){ 

  include_once("view/header_html.php");

  ?>

<div class="main-mobile">
    <div class="row">
        <div class="col-12">
            <div class="card ">
            <div class="card-header">
                <h3>Hotspot &nbsp; <span id="loadingX"></span></h3>
            </div>
            <div class="card-body">
            <div class="row">
                <div class="col-12 mr-b-10">
                    <div class="btn-group">
                        <button class="bg-grey" onclick="loadUserProfiles()" id="btn-user-profiles"><i class="fa fa-pie-chart" ></i> User Profile</button> 
                        <button class="bg-grey" onclick="loadUsersPP()" id="btn-hotspot-users"><i class="fa fa-users" ></i> Hotspot Users</button>
                    </div>
                    
                </div>
                
                <div class="col-12 hide" id="user-profiles">
                    <div class="">
                    <div class="btn-group">
                        <button class="bg-grey" onclick="loadUserProfiles()" id="btn-add-user-profiles"><i class="fa fa-plus" ></i>  Add</button> 
                    
                        <button class="bg-grey" onclick="loadUProfiles()"><i class="fa fa-refresh" ></i></button>

                    </div>
                    <hr>
                    </div>
                    <div class="card-fixed">
                    
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <td>Name</td>
                                <td>Shared Users</td>
                                <td>Rate Linit</td>
                                <td>Epired Mode</td>
                                <td>Validity</td>
                                <td>Price</td>
                                <td>Selling Price</td>
                                <td>User Lock</td>
                            </tr>
                        </thead>
                        <tbody id="profiles">

                        </tbody>
                    </table>
                    </div>
                </div>
                <div class="col-12 hide" id="hotspot-users">
                    <div class="">
                    <div class="btn-group">
                        <button class="bg-grey" onclick="" id="btn-add-hotspot-users"><i class="fa fa-plus" ></i> Add</button> 
                        <button class="bg-grey" onclick="" id="btn-gen-hotspot-users"><i class="fa fa-ticket" ></i> Generate</button>
                        <button class="bg-grey" onclick="loadUsersPPF()"><i class="fa fa-refresh" ></i></button>
                    </div>
                    <hr>
                    </div>
                    <div class="card-fixed">
                    
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <td>Name</td>
                                <td>Profile</td>
                                <td class="text-right">Uptime</td>
                                <td class="text-right">Bites In</td>
                                <td class="text-right">Bytes Out</td>
                                <td>Comment</td>
                            </tr>
                        </thead>
                        <tbody id="users">

                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            </div>
            <div class="card-footer"><span id="loading"></span> </div>
            </div>
        </div>
    </div>
</div>


<?php } ?>
<script>
    
$(document).ready(function() {
$("#user-profiles").removeClass('hide').addClass('block');
loadUProfiles()




})


</script>

<?php
include_once("view/footer_html.php");
}
?>
