setting IP, username & password Mikrotik 

=> config => connection.php


setting interface traffic monitor 
=> index.php variable $iface = "interface-name"
