setting IP, username & password Mikrotik 

=> config => connection.php


setting interface traffic monitor 
=> view => footer_html.php variable $iface = "interface-name"
