function formatBytes(value) {                           
    var sizes = ['Byte', 'KiB', 'MiB', 'GiB', 'TiB'];
    if (value == 0) return '0 Byte';
    var i = parseInt(Math.floor(Math.log(value) / Math.log(1024)));
    return parseFloat((value / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];                    
  }
  
function formatHz(numm) {                           
   // return numm.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')+ ' MHz';                   
 }

function currencyFormat(num,curr="$") {
   if(curr == "Rp" || curr == "RP" || curr == "IDR" || curr == "rp" ){
       return (
           "<span style='font-size:20px;'>"+curr+"&nbsp;</span>" + num
             .toFixed(0)
             .replace('.', ',')
             .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.') 
         )
   }else{
       return curr +"&nbsp" + num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
   }
}


function currencyFormatSF(num,curr="$") {
    if(curr == "Rp" || curr == "RP" || curr == "IDR" || curr == "rp" ){
         var tot = num
         .toFixed(0)
         .replace('.', ',')
         .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.') 
         numL = tot.split(".").length
         if(numL == 1 || numL == 2){
            a = "<span style='font-size:40px;'>"+tot.split(".")[0]+"</span>"
            b = tot.substring((tot.split(".")[0]).length),tot.length
         } else if(numL == 3){
            a = "<span style='font-size:40px;'>"+tot.split(".")[0]+"."+tot.split(".")[1]+"</span>"
            b = "."+tot.split(".")[2]
         }
        return (
            "<span style='font-size:15px;position:absolute;margin-left:-20px;'>"+curr+"&nbsp;</span>" + a + b
          )
    }else{
      var tot = num
      .toFixed(2)
      .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') 
      a = "<span style='font-size:40px;'>"+tot.split(",")[0]+"</span>"
      b = tot.substring((tot.split(",")[0]).length),tot.length
     return (
         "<span style='font-size:15px;position:absolute;margin-left:-20px;'>"+curr+"&nbsp;</span>" + a + b
       )
    }
}

function nFormat(num) {
        return "<span style='font-size:40px;'>"+num+"</span>"    
 }

 function nFormatMobile(num) {
   return "<span style='font-size:30px;'>"+num+"</span>"    
} 




function timeNice(time){
var w = time.search("w");
var d = time.search("d");
var h = time.search("h");
var m = time.search("m");
var s = time.search("s");


if(w > 0){
   weak = Number(time.split("w")[0])*7
   t_day = time.substring(w+1,time.legth)
   
}else if(w < 0){
   weak = ""
   t_day = time.substring(time.legth)
}

if(d > 0){
    if(weak > 0){
        day = Number(t_day.split("d")[0])
    }else{
        day = t_day.split("d")[0]
    }

   t_hour = time.substring(d+1,time.legth)
}else if(d < 0){
   day = ""
   t_hour = t_day.substring(time.legth)

}

if(h > 0){
   hour = t_hour.split("h")[0]
   if(hour.length == 1){
      hour = "0"+hour+":"
   }else{
      hour = hour+":"
   }
   t_minute = time.substring(h+1,time.legth)
}else if(h < 0){
   hour = "00:"
   t_minute = time.substring(d+1,time.legth)
}

if(m > 0){
   minute = t_minute.split("m")[0]
   if(minute.length == 1){
      minute = "0"+minute
   }
   t_sec = time.substring(m+1,time.legth)
}else if(m < 0 && h < 0){
   minute = "00"
   t_sec = time.substring(d+1,time.legth)
}else if(m < 0 ){
   minute = "00"
   t_sec = time.substring(h+1,time.legth)
}

if(s > 0){
   sec = t_sec.split("s")[0]
   if(sec.length == 1){
      sec = ":0"+sec
   }else{
      sec = ":"+sec
   }
}else if(s < 0){
   sec = ":00"

}
var totDay = (Number(weak)+Number(day))
if(totDay < 1){
   totDay = ""
}else{
   totDay = totDay + "d "
}

return ( totDay + hour + minute + sec)

}



function ucFirst(value){
   a = value.substring(0,1)
   b = value.substring(1,value.length)
   return a.toUpperCase()+b
}