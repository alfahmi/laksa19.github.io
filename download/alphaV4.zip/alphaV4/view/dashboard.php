<?php 
session_start();
// hide all error
error_reporting(0);
// protect .php
$get_self = explode("/",$_SERVER['PHP_SELF']);
$self[] = $get_self[count($get_self)-1];

if($self[0] !== "index.php"  && $self[0] !==""){
    include_once("../core/func.php");

    e403();

}else{

  $is_mobile = $_GET['mobile'];

if(!isset($is_mobile)){
  

$dash_ma = "sidenav_active";

include_once("view/header_html.php");
include_once("view/menu.php");


?>

<div class="main unselect" >
  <div class="row">
    <div class="col-12">
      <div class="box box-bordered" style="font-size: 14px; font-weight:bold;">
        <div class="row">
          <!-- <div class="text-left col-4"><?= strtoupper($m_user) ?></div> -->
          <div class="text-left col-6" id="load-json">Loading Data...</div>
          <div class="text-right col-6 unselect">
            <span id="time-zone">-</span> | 
            <span id="time">-</span> | 
            <span id="date">-</span>
          </div>
        </div>
      
      </div>
    </div>
    <div class="col-12">
      <div class="row">
        <div class="col-4">
          <div class="box bmh-60 box-red">
            <div class="box-group">
              
                <div class="box-group-area">
                  
                  <span class="box-group-text" id="hotspot-active">-</span><br>
                  
                </div>
                <div class="box-group-icon"><i class="fa fa-wifi"></i><div>Active</div></div>
            </div>
            
          </div>
        </div>
          <div class="col-4">
            <div class="box bmh-60 box-yellow">
              <div class="box-group">
                  <div class="box-group-area">
                    <span class="box-group-text" id="hotspot-users">-</span>
                  </div>
                  <div class="box-group-icon"><i class="fa fa-users"></i><div>Users</div></div>
              </div>
            </div>
          </div>
          <div class="col-4">
            <div class="box bmh-60 box-green">
              <div class="box-group">
                  <div class="box-group-area">
                    <span class="box-group-text" id="live-report">-</span>
                  </div>
                  <div class="box-group-icon"><i class="fa fa-money"></i><div>Income</div></div>
              </div>
            </div>
          </div>
      </div>
    </div>
    <div class="col-12">
      <div class="row">
        <div class="col-4">
          <div class="card">
            <div class="card-header">
              <h3><i class="fa fa-server"></i> Resource</h3>
            </div>
            <div class="card-body">
              
                <table class="table table-hover unselect" style="font-size: 13px;">
                  <tr>
                    <td>CPU Load</td>
                    <td>
                      <div class="bg-grey radius-3">
                        <div class="bg-primary text-nowrap radius-3" id="prog-cpu"><span class="mr-l-5" id="cpu-load">-</span></div>
                      </div>
                      
                    </td>
                  </tr>
                  <tr>
                    <td>Memory</td>
                    <td>
                      <div class="bg-primary radius-3">
                        <div class="bg-grey text-nowrap radius-3"  id="prog-memory"><span class="mr-l-5" id="memory">-</span></div>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>HDD</td>
                    <td>
                      <div class="bg-primary radius-3">
                        <div class="bg-grey text-nowrap radius-3"  id="prog-hdd"><span class="mr-l-5" id="hdd">-</span></div>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>Voltage</td>
                    <td><span id="voltage">-</span></td>
                  </tr>
                  <tr>
                    <td>Temperature</td>
                    <td><span id="temperature">-</span></td>
                  </tr>
                </table>
              </div>
          </div>
        </div>
          
          <div class="col-5">
            <div class="card">
              <div class="card-header">
                <h3><i class="fa fa-info-circle"></i> System</h3>
              </div>
              <div class="card-body">
                <table class="table table-hover unselect" style="font-size: 13px;">
                  <tr>
                    <td>Uptime</td>
                    <td><span id="uptime">-</span></td>
                  </tr>
                  <tr>
                    <td>Board Name</td>
                    <td><span id="board-name">-</span></td>
                  </tr>
                  <tr>
                    <td>Model</td>
                    <td><span id="model">-</span></td>
                  </tr>
                  <tr>
                    <td>Router OS</td>
                    <td><span id="version">-</span></td>
                  </tr>
                  <tr>
                    <td>Architecture</td>
                    <td><span id="architecture">-</span></td>
                  </tr>
                </table>
                  
            </div>
            
          </div>
      </div>
      <div class="col-3">
        <div class="card">
          <div class="card-header">
            <h3><i class="fa fa-ticket"></i> Voucher</h3>
          </div>
          <div class="card-body text-center" style="max-height: 145px;min-height: 145px; vertical-align:middle;">
            <div class="row">
              <div class="bmh-40 box bg-primary"><i class="fa fa-user-plus"></i> Add</div>
              <div class="bmh-40 box bg-primary"><i class="fa fa-user-plus"></i> Generate</div>
            </div>
          </div>

        </div>
      </div>
    </div>
    <div class="col-12">
      <div class="row">
        <div class="col-8">
          <div class="card">
            <div class="card-header">
              <h3><i class="fa fa-area-chart"></i> Traffic Monitor</h3>
            </div>
            <div class="card-body">
              <div style="padding-right: 10px;" id="trafficMonitor"></div>
            </div>
          </div>
        
        </div>
          <div class="col-4">
            <div class="card">
              <div class="card-header">
                <h3><i class="fa fa-file-text"></i> Log</h3>
              </div>
              <div class="card-body">
                <div style="padding: 5px; height: 280px ;" class="mr-t-10 overflow">
                  <table class="table table-bordered table-hover unselect" style="font-size: 12px;">
                    <thead>
                      <tr>
                        <td>Time</td>
                        <td>User (IP)</td>
                        <td>Messages</td>
                      </tr>
                    </thead>
                    <tbody  id="log">
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            
          </div>
      </div>
    </div>
    

  </div>

  </div>

</div>

<?php 

}else if(isset($is_mobile)){ 

  include_once("view/header_html.php");

  ?>

  <div class="main-mobile" >
    <div class="mobile-dashboard-top bg-primary">
    <div class="text-right unselect pd-5">
            <span id="time-zone">-</span> | 
            <span id="time">-</span> | 
            <span id="date">-</span>
          </div>
  <div class="container-mobile-head">
    
        <div class="mobile-container text-middle">
          <div class="image-circle-box">
            <div class="image-circle-mobile" style="background-image: url('assets/img/logo-<?= $m_user ?>.png')"></div>
          </div>
        
            <div class="pd-t-10 live-report-mobile">
            <span id="live-report">-</span>
            </div>
          
          
     
    </div>
  </div>
  <div class="text-left pd-l-5" id="load-json">Loading Data...</div>
  </div>



  <div class="mobile-body">
      <div class="row">
        <div class="col-6">
          <div class="box bmh-60 box-red">
            <div class="box-group">
              
                <div class="box-group-area">
                  
                  <span class="box-group-text" id="hotspot-active">-</span><br>
                  
                </div>
                <div class="box-group-icon"><i class="fa fa-wifi"></i><div>Active</div></div>
            </div>
            
          </div>
        </div>
          <div class="col-6">
            <div class="box bmh-60 box-yellow">
              <div class="box-group">
                  <div class="box-group-area">
                    <span class="box-group-text" id="hotspot-users">-</span>
                  </div>
                  <div class="box-group-icon"><i class="fa fa-users"></i><div>Users</div></div>
              </div>
            </div>
          </div>
          
      </div>
  </div>
    <div class="w-12">

         
            <div class="mobile-card">
              <h3><i class="fa fa-server"></i> System Resource</h3>
            
                <table class="table table-hover unselect" style="font-size: 13px;">
                  <tr>
                    <td>CPU Load</td>
                    <td>
                      <div class="bg-grey radius-3">
                        <div class="bg-primary text-nowrap radius-3" id="prog-cpu"><span class="mr-l-5" id="cpu-load">-</span></div>
                      </div>
                      
                    </td>
                  </tr>
                  <tr>
                    <td>Memory</td>
                    <td>
                      <div class="bg-primary radius-3">
                        <div class="bg-grey text-nowrap radius-3"  id="prog-memory"><span class="mr-l-5" id="memory">-</span></div>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>HDD</td>
                    <td>
                      <div class="bg-primary radius-3">
                        <div class="bg-grey text-nowrap radius-3"  id="prog-hdd"><span class="mr-l-5" id="hdd">-</span></div>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>Voltage</td>
                    <td><span id="voltage">-</span></td>
                  </tr>
                  <tr>
                    <td>Temperature</td>
                    <td><span id="temperature">-</span></td>
                  </tr>
                  <tr>
                    <td>Uptime</td>
                    <td><span id="uptime">-</span></td>
                  </tr>
                  <tr>
                    <td>Board Name</td>
                    <td><span id="board-name">-</span></td>
                  </tr>
                  <tr>
                    <td>Model</td>
                    <td><span id="model">-</span></td>
                  </tr>
                  <tr>
                    <td>Router OS</td>
                    <td><span id="version">-</span></td>
                  </tr>
                  <tr>
                    <td>Architecture</td>
                    <td><span id="architecture">-</span></td>
                  </tr>
                </table>
              </div>
  

            <div class="mobile-card">
              <h3><i class="fa fa-area-chart"></i> Traffic Monitor</h3>
            
              <div style="padding-right: 10px;" id="trafficMonitor"></div>
            </div>
          

            
              <div class="mobile-card">
                <h3><i class="fa fa-file-text"></i> Log</h3>
              
                <div style="padding: 5px; height: 400px ;" class="mr-t-10 overflow">
                  <table class="table table-bordered table-hover unselect" style="font-size: 12px;">
                    <thead>
                      <tr>
                        <td>Time</td>
                        <td>User (IP)</td>
                        <td>Messages</td>
                      </tr>
                    </thead>
                    <tbody  id="log">
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tbody>
                  </table>
                </div>
              </div>
           
            
          </div>
      </div>


 



<?php } ?>

<script>

var session = localStorage.getItem('session') 
var currency = localStorage.getItem(session+'Curr');
var iface = localStorage.getItem(session+'Iface');


$(document).ready(function() {

localStorage.setItem(session+"_profn",0);    
txrx = '[{"name":"Tx","data":["0"]},{"name":"Rx","data":["0"]}]'
localStorage.setItem(session+"_traffic_data",txrx)  

dashboard()
trafficMonitor()
})



</script>




<?php
include_once("view/footer_html.php");
}
?>
