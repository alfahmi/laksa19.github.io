<?php
session_start();
// hide all error
error_reporting(0);
// protect .php
$get_self = explode("/",$_SERVER['PHP_SELF']);
$self[] = $get_self[count($get_self)-1];

if($self[0] !== "index.php"  && $self[0] !==""){
    include_once("../core/func.php");

    e403();

}else{

?>

<div class="sidenav unselect">
  <div class="text-center" id="brand">MIKHMON ONLINE</div>
  <div class="image-circle" style="background-image: url('assets/img/logo-<?= $m_user ?>.png')"></div>
  <a href="?<?= $m_user ?>" class="sidenav_item <?= $dash_ma ?>" ><i class="fa fa-th-large"></i> Dashboard</a>
  <a href="?<?= $m_user ?>/hotspot" class="sidenav_item <?= $hotspot_ma ?>"><i class="fa fa-wifi"></i> Hotspot</a>
  <a href="?<?= $m_user ?>/hotspot" class="sidenav_item <?= $quickprint_ma ?>" ><i class="fa fa-print"></i> Quick Print</a>
  <a href="?<?= $m_user ?>/hotspot" class="sidenav_item <?= $log_ma ?>" ><i class="fa fa-file-text"></i> Log</a>
  <a href="?<?= $m_user ?>/hotspot" class="sidenav_item <?= $report_ma ?>" ><i class="fa fa-money"></i> Report</a>
  <a href="?<?= $m_user ?>/hotspot" class="sidenav_item <?= $system_ma ?>" ><i class="fa fa-gears"></i> System</a>
  <a href="?<?= $m_user ?>/hotspot" class="sidenav_item <?= $settings_ma ?>" ><i class="fa fa-gear"></i> Settings</a>

 
</div>

<?php } ?>