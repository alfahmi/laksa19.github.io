<?php

include_once("../core/func.php");


// routeros api
  include_once('core/routeros_api.class.php');

  $API = new RouterosAPI();
  $API->debug = false;

  $API->connect("ip-mikrotik", "username", "password");



?>

