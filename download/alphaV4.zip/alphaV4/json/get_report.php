<?php

session_start();
// hide all error
error_reporting(0);
// protect .php
$get_self = explode("/",$_SERVER['PHP_SELF']);
$self[] = $get_self[count($get_self)-1];

if($self[0] !== "index.php"  && $self[0] !==""){
    include_once("../core/func.php");

    e403();

}else{


include_once("../core/func.php");
$day = $_GET['day'];

include_once("config/connection.php");


  if(isset($_GET['day'])){
    $get_report = $API->comm("/system/script/print", array(
      "?source" => "$day",
    ));
  }else{
    $get_report = $API->comm("/system/script/print", array(
      "?owner" => "dec2019",
    ));
  }

      echo json_encode($get_report);
    
}
 ?>