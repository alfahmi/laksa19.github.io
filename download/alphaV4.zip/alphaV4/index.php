<?php 
//
session_start();
error_reporting(0);
    

$_SESSION["mikhmon"] = "laksa";

include_once("core/func.php");
include_once("config/page.php");



$r_uri = $_SERVER['REQUEST_URI'];
$uri_path =  explode("/",explode("?",explode("&",$r_uri)[0])[1]);
$n_uri_path = count($uri_path);
$max_path = 3;

$m_user =  $uri_path[0];
$page = $uri_path[1];
$act = $uri_path[2];
$_SESSION['m_user'] = $m_user;



if (!isset($_SESSION["mikhmon"])) {
    echo "Login";
}else if(empty($m_user) && empty($page) || $m_user == "admin" && empty($page)){
    header('Location: ./?mikhmon');
    
    
}else{
    if($m_user ==  "admin"){
        route("admin",$page,$admin_page);
   
    }else{
        if(!empty($m_user) && empty($page)){
            include_once($m_user_page['dashboard']);
        }else{
            route($m_user,$page,$m_user_page);
        }
    }
}


