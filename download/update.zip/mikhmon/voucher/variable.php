
Logo :
<img src="<?php echo $logo;?>" style="height:30px;border:0;">

Hotspotname :
<?php echo $hotspotname;?>

Username :
<?php echo $username;?>

Password :
<?php echo $password;?>

Validity :
<?php echo $validity;?>

Time Limit :
<?php echo $timelimit;?>

Data Limit :
<?php echo $datalimit;?>

Price :
<?php echo $price;?>

Comment :
<?php echo $comment;?>

QR Code :
<img src="<?php echo $qrcode ?>">

Number Voucher:
<?php echo $num;?>
<span id="num"><?php echo " [$num]";?></span>

Conditional :
$usermode = "vc"
username=password

$usermode = "up"
username&password