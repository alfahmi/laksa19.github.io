<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// hide all error

session_start();
error_reporting(0);
require('../lib/routeros_api.class.php');
include('../lib/formatbytesbites.php');
include('../include/config.php');

  
$API = new RouterosAPI();
$API->debug = false;
$API->connect( $iphost, $userhost, decrypt($passwdhost));

$hotspotuser = $_GET['name'];
if($hotspotuser != ""){
	
	
  $getprofile = $API->comm("/ip/hotspot/user/profile/print");
  $srvlist = $API->comm("/ip/hotspot/print");
  
   
  $getuser = $API->comm("/ip/hotspot/user/print", array(
    "?name"=> "$hotspotuser",
    ));
	
	$userdetails =	$getuser[0];
	$uid = $userdetails['.id'];
	$uname = $userdetails['name'];
  $upass = $userdetails['password'];
  
}

  
?>

<?php
  if(isset($_POST['name'])){

    $name = ($_POST['name']);
    $password = ($_POST['pass']);
	
    $API->comm("/ip/hotspot/user/set", array(
	    ".id"=> "$uid",
	    "name" => "$name",
	    "password" => "$password",
	    ));
    echo '<meta http-equiv="refresh" content="5;URL="editpass.php?name='.$uname.'" />';
	$berhasil = 'Berhasil diperbaharui';
   }
?>


<!DOCTYPE html>
<html>
<head>
<title><?php echo $title." ".$hotspotname;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="pragma" content="no-cache" />
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;"/>
<!-- Font Awesome -->
<link rel="stylesheet" type="text/css" href="../css/font-awesome/css/font-awesome.min.css" />
<!-- Mikhmon UI -->
<link rel="stylesheet" href="../css/mikhmon-ui.css">
<link rel="icon" href="../img/favicon.png" />


<script>
  function PassUser(){
    var x = document.getElementById('passUser');
    if (x.type === 'password') {
    x.type = 'text';
    } else {
    x.type = 'password';
    }}
</script>
</head>
<body >
<div class="login-box" style="padding-top: 10px;">
<h3 class="text-center">Ganti Password Users Members</h3>
<p class="text-center"></p>

<section>
<div class="card">
<div class="card-header">
    <h3>
      <i class="fa fa-user mr-1"></i>
        Akun Anda : <b><?php echo $uname;?>
    </h3>
  </div>
  <div class="card-body">
  
<form autocomplete="off" class="form" method="post" action="">
	<div class="input-group">
        <div class="input-group-8">
			<input type="hidden" class="group-item group-item-l" name="name" placeholder="<?php echo $name;?>" autofocus required="1"  value="<?php echo  $uname;?>"/>
			<input type="password" class="group-item group-item-l" id="passUser" name="pass" placeholder="<?php echo $title1;?>" autofocus required="1"  value="<?php echo  $upass;?>"/>
		</div>
		<div class="input-group-1">
      <div class="group-item group-item-md pd-2p5 text-center align-middle">
          <input title="Show/Hide Password" type="checkbox" onclick="PassUser()">
      </div>
		</div>
		<div class="input-group-3">
			<button type="submit" style="cursor: pointer; padding: 2.5px;" class="group-item group-item-r"><i class="fa fa-lock"></i> <?php echo " ".$title12;?></button>
		</div>
</div>
</form>
	<div style="display:block;"><?php echo $berhasil;?></div>
  
</div>
</div>
</section>
</div>
</div>
</body>
</html>


